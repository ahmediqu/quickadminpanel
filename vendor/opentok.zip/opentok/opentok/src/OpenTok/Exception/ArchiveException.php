<?php

namespace OpenTok\Exception;

/**
* The interface used by all exceptions resulting from calls to the archiving API.
*/
interface ArchiveException
{
}
/* vim: set ts=4 sw=4 tw=100 sts=4 et :*/
